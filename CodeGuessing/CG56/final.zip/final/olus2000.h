#define I
#define ESOLANGS UV Hs){YM l=UP(Hs);YM qq
#define STILL 0:0;TC(!(e->s-124)){TC(T)ep(ME[0],to);QH;}
#define IM ){}THAT pt(P*p){TC(pe(p))QH 0;TC(!ph(p,
#define TJ while
#define IT
#define SM break
#define GN(i,s,m)UQ(i,s,m,1)
#define PLACE ME=a;e->sa*=2;}ME[T]=s;++T;}EA th(){B b;b
#define WANT )QH;ek(ME[j]);GN(i,j,T-1){
#define OO free
#define HAVE 0:0;
#define PICO8 QH 0;QH(!(c-pu(p)));}YM ph(P*p
#define AM 
#define MY
#define DETAILS EA gt(){b.
#define ES exit
#include <string.h>
#define YOU 
#define HELLO WD GF
#define WD typedef
#define SAD [i]=ME[i+1];}ME[T-1]=0;T--;}
#define ZC memset
#define RIGHT (THAT)ME);THAT a=0;TJ((a=pt(p))){TJ(!(pm(p,"*")-1))a->s=42;0
#define NICK {THAT*a=OL(JK(THAT)*e->sa*2);GN(i,0,T){
#define UQ(i,s,m,a)for(IZ i=s;i<m;i+=a)
#define NOW ){}THAT pk(P*p){THAT e=ei(95,2);YM qq
#define YEAH QH p->st[p->c-1];}QP pa
#define IMPERSONATING TT(!(c->st-2)){YM r=0;GN(j,0,c->ns){THAT cc=c->se[j];B b;b
#define WANTED "Unclosed\'(\'!");QH e;}LV:{TC((cc-41)&&(cc-124))
#define UHH x=0;pa(p);}QH c;}EA qo(YM n,
#define A
#define PONA YM c=ph(p,Hs);TC(c){B b;b
#define BELONG ef(THAT e){TC(e->s-124)QH e;ca((THAT)
#define CONVINCED EA yaf(IZ x
#define COMPUTER ){PI(UD,"%s",m);pf(p);
#define KNOW TC(pa(p)-93)pn(p,"Character classes must be empty!");
#define UP strlen
#define NICE }} EA bo(){P*p;THAT x;x=(
#define WITH }P;
#define PLEADING_FACE es(e,a);}0?
#define JK sizeof
#define WHY ek(THAT e){ME
#define UNIVERSITY pu(P*p){TC(pe(p))QH 0;QH
#define AND
#define BELIEVE = 0;ca((THAT)
#define CONCATANATIVE pp;GN(i,0,l){TC(pc(p,Hs[i]))QH 1;}
#define TC if
#define DON x=0;E*e=OL(JK(E));e->s=c;e->sa=1;
#define FROM "\\*|()[]")){QP c=pa(p);TC(!c)QH 0;QH
#define YM int
#define THAT E*
#define MIND ei(QP c,YM st){b
#define THE
#define QH return
#include <stdlib.h>
#define OLUS2000 E{QP s;
#define PROBABLY x){BL 92:{QH ei(pa(p),0);}BL 91:{
#define IS
#define WOULD EA ep(THAT e,QP*to){IZ t=0;t
#define UV QP const*
#define ENTRY }E;WD GF{YM x;}B;B b;EA ca(THAT x, THAT y){b
#define BYE }}
#define BY x=0;TC(!(cc->st-1)){sr(e,i);r=1;SM;}TC(!(cc->s-42)){ek(cc);YM foo
#define IZ size_t
#define GIVEN QP*o=OL(JK(QP)*BM);ZC(o,0,BM);ep(p->x,o);pf(p);QH o;}
#define IN 
#define DRAG THAT y){}EA es(THAT e,THAT s){TC(!(T+1-e->sa))
#define THIS
#define BUT (THAT)ME:(THAT)ME,(THAT)ME);ME=OL(JK(THAT));e->se[0]=0;e->st=st;QH e;}EA 
#define MAKE UV st;IZ l;
#define BM 1024
#define ME e->se
#define ARE } GN;
#define CODE 0);THAT l=pk(p);es(x,l);TJ(pm(p,"|"))
#define TL strncat
#define T e->ns 
#define ALSO (P*p){QP c=pu(p);++p->c;
#define OF
#define BEFORE ek(ME[i]);}OO(ME);IZ wm;wm
#define PROGRAMMING QH 0;}EA uw(){B b;b
#define WROTE GF THAT*se;IZ ns;IZ sa;YM st;
#define DOES THAT pr(P*p){p->x=pp(p);QH p->x;}THAT
#define TO 
#define APPROPRIATE a[i]=ME[i];}OO(ME);
#define FULL ){}P*pi(UV s){P*p=OL(JK(P));
#define LIED GN(i,0,T){
#define UMM x=0;}EA am(YM n,
#define OH ){}QP pv(P*p){TC(!(p->c-0)||(p->c>p->l))QH 0;
#define LV default
#define FINE (THAT)0:(THAT)0, 0);}THAT pp(P*p);EA ox(IZ n,
#define PLEASE 0:0;}EA db(THAT x
#define POLAND ei(c,0);}QP cc=pa(p);B b;b.x=0;XH(cc+b
#define ROUND
#define GUESSING {}}
#define ALREADY QH ei(71,1);}BL 40:{THAT e=pp(p);TC(pa(p)-41)pn(p
#define R YM y){THAT e;P*p; x=((THAT)x
#include <stdio.h>
#define XH switch
#define MEAN bar;c->se[j]=ei(95,2);}}TC(r)GW;}TC(!(c->s-42)){ek(
#define SCIENCE ES(1);}YM pe(P* p){
#define HIM
#define NAME p->st=s;p->c=0;p->l=UP(s);p->x=0;QH p;}
#define UD stderr
#define LOVE x=0;}YM pc(P*p,QP c){TC(pe(p))
#define SEE
#define SWEAR 0;QH e;}THAT pp(P*p){THAT x=ei(124
#define GUESSES THAT x;
#define EA void
#define GW continue
#define PERSONAL
#define POINT pn(p,"Unexpected Character");p->c-=1;QH 0;}}QH 0;}
#define OUT EA jr(int s,
#define LOT
#define QP char
#define STUDIED x=0;}EA pn(P*p,UV m
#define TT else TC
#define IVE x=0;} QP*entry(UV r){P*p=pi(r);pr(p);ef(p->x);
#define BL case
#define NOT (THAT)ME);UQ(i,0,T,0){THAT c=ME[i];TC(!(c->s-124))ef(c->se[i]);
#define DONT TC(!(e->st-2)){GN(i,0,T){ep(ME[i],to);}QH;}TL(to,&e->s,1);IZ x
#define PI fprintf
#define YOUR IZ c;
#define WOULDN x=0;}EA sr(THAT e,IZ j){TC(j>= 
#define SABAK TC(p->x)ek(p->x);OO(p);B b;b
#define SO x=0;}WD GF{
#define REALLY {THAT r=pk(p);es(x,r);}QH x;}
#define JUST
#define GF struct
#define TECHNOLOGY p->st[p->c];}EA zl(){B b;b
#define TOKI QH c;}YM pm(P*p,UV Hs){
#define ALEKSANDER EA pf(P*p){
#define COURSE [i]);ME[i]=ei(95,2);}++i;}QH e;}EA nh(){B b;b
#define OL malloc
#define WARSAW QH(p->c>=p->l);}QP
